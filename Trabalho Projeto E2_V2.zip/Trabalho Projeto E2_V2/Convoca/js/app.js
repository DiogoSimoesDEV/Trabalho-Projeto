(function () {
  const KEY = "convoca-v1";

  const $ = (sel, root = document) => root.querySelector(sel);

  function uid(prefix) {
    return prefix + Math.random().toString(36).slice(2, 9);
  }

  function nowClock() {
    const d = new Date();
    return d.toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" });
  }

  function fmtWhen(iso) {
    const d = new Date(iso);
    const weekday = d.toLocaleDateString("pt-PT", { weekday: "long" });
    const day = d.toLocaleDateString("pt-PT", { day: "numeric", month: "short" });
    const time = d.toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" });
    const nice = weekday.charAt(0).toUpperCase() + weekday.slice(1);
    return { nice, day, time, label: `${nice}, ${time}`, short: `${nice.slice(0, 3)}. ${time}` };
  }

  function toast(msg) {
    const el = $("#toast");
    el.textContent = msg;
    el.classList.add("show");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.classList.remove("show"), 2200);
  }

  function defaultPlayers() {
    const names = [
      ["Inês Costa", "ines@email.pt", "912 000 002", true],
      ["Rui Mendes", "rui@email.pt", "912 000 001", true],
      ["João Silva", "joao@email.pt", "912 000 003", false],
      ["Marta Dias", "marta@email.pt", "912 000 004", true],
      ["Pedro Alves", "pedro@email.pt", "912 000 005", true],
      ["Sofia Nunes", "sofia@email.pt", "912 000 006", true],
      ["Tiago Rocha", "tiago@email.pt", "912 000 007", true],
      ["Ana Ferreira", "ana@email.pt", "912 000 008", true],
      ["Luís Carvalho", "luis@email.pt", "912 000 009", true],
      ["Beatriz Lopes", "beatriz@email.pt", "912 000 010", true],
      ["Nuno Teixeira", "nuno@email.pt", "912 000 011", true],
      ["Carla Sousa", "carla@email.pt", "912 000 012", true],
      ["André Pinto", "andre@email.pt", "912 000 013", true],
      ["Filipa Ramos", "filipa@email.pt", "912 000 014", true],
      ["Bruno Costa", "bruno@email.pt", "912 000 015", true],
      ["Sara Vieira", "sara@email.pt", "912 000 016", true],
      ["Diogo Martins", "diogo@email.pt", "912 000 017", true],
      ["Helena Cruz", "helena@email.pt", "912 000 018", true]
    ];
    return names.map(([name, email, phone, active], i) => ({
      id: "p" + (i + 1),
      name,
      email,
      phone,
      active
    }));
  }

  function seed() {
    const players = defaultPlayers();
    const called = players.filter((p) => p.active).map((p) => p.id);
    const yes = ["p2", "p4", "p5", "p6", "p7", "p8", "p9", "p10", "p11", "p12", "p13", "p14"];
    const no = ["p15", "p16"];
    const responses = {};
    called.forEach((id) => {
      if (yes.includes(id)) responses[id] = "yes";
      else if (no.includes(id)) responses[id] = "no";
      else responses[id] = null;
    });
    const closedResponses = {};
    called.forEach((id, i) => {
      closedResponses[id] = i % 5 === 0 ? "no" : "yes";
    });
    return {
      coaches: [
        { id: "c1", name: "Miguel Santos", email: "miguel@email.pt", pass: "convoca" }
      ],
      team: { name: "FC Amadora", code: "EQ-K7P2M9", coachId: "c1" },
      players,
      games: [
        {
          id: "g1",
          opponent: "Académico",
          venue: "Campo da Moita",
          datetime: "2026-10-31T10:00",
          notes: "Concentração às 9h15.",
          closed: false,
          called,
          responses
        },
        {
          id: "g2",
          opponent: "Benavente",
          venue: "Fora",
          datetime: "2026-10-18T15:00",
          notes: "",
          closed: true,
          called,
          responses: closedResponses
        }
      ],
      session: null
    };
  }

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return seed();
      return JSON.parse(raw);
    } catch {
      return seed();
    }
  }

  function save() {
    localStorage.setItem(KEY, JSON.stringify(db));
  }

  let db = load();

  function go(hash) {
    location.hash = hash;
  }

  function parseRoute() {
    const h = (location.hash || "#/").replace(/^#/, "");
    const parts = h.split("/").filter(Boolean);
    return { parts, path: "/" + parts.join("/") };
  }

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function brand(extra = "") {
    const home = db.session && db.session.role === "coach" && db.team ? "#/painel" : "#/";
    return `<div class="top-row">
      <a class="brand" href="${home}"><span class="mark">C</span> Convoca</a>
      ${extra}
    </div>`;
  }

  function nav(active) {
    const items = [
      ["painel", "Painel", "⌂"],
      ["equipa", "Equipa", "⚑"],
      ["jogadores", "Jogadores", "☰"],
      ["jogos", "Jogos", "◎"]
    ];
    return `<nav class="bottom-nav" aria-label="Principal">${items
      .map(
        ([id, label, icon]) =>
          `<a href="#/${id}" ${active === id ? 'aria-current="page"' : ""}><span>${icon}</span>${label}</a>`
      )
      .join("")}</nav>`;
  }

  function requireCoach() {
    if (!db.session || db.session.role !== "coach") {
      go("/login");
      return false;
    }
    if (!db.team) {
      go("/criar-equipa");
      return false;
    }
    return true;
  }

  function coach() {
    return db.coaches.find((c) => c.id === db.session.coachId);
  }

  function counts(game) {
    let yes = 0, no = 0, wait = 0;
    game.called.forEach((id) => {
      const r = game.responses[id];
      if (r === "yes") yes++;
      else if (r === "no") no++;
      else wait++;
    });
    return { yes, no, wait, total: game.called.length };
  }

  function nextOpenGame() {
    return db.games
      .filter((g) => !g.closed)
      .sort((a, b) => a.datetime.localeCompare(b.datetime))[0];
  }

  function playerById(id) {
    return db.players.find((p) => p.id === id);
  }

  function tokenFor(gameId, playerId) {
    return `${gameId}.${playerId}`;
  }

  function parseToken(token) {
    const [gameId, playerId] = (token || "").split(".");
    return { gameId, playerId };
  }

  function copy(text, ok) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => toast(ok)).catch(() => toast(text));
    } else {
      toast(text);
    }
  }

  function shellPublic(title, lead, inner, topRight = "") {
    return `<div class="screen">
      <header class="hero">
        ${brand(topRight)}
        <h1>${title}</h1>
        <p>${lead}</p>
      </header>
      <div class="body">${inner}</div>
    </div>`;
  }

  function viewInicio() {
    db.session = null;
    save();
    return shellPublic(
      "Convocatórias sem perseguir o grupo",
      "O treinador envia o jogo. Cada jogador abre o seu link e diz se vai.",
      `<div class="stack">
        <a class="btn" href="#/login">Sou treinador</a>
        <a class="btn btn-sec" href="#/entrar-equipa">Sou jogador · entrar na equipa</a>
        <a class="btn btn-sec" href="#/c/${tokenFor("g1", "p1")}">Abri o link do jogo</a>
      </div>
      <p class="lead" style="margin-top:20px">Ainda não tens conta de treinador? <a href="#/registo"><strong>Criar conta</strong></a></p>
      <p class="demo">Demo treinador: miguel@email.pt · convoca<br>Código da equipa: EQ-K7P2M9<br>
      <button class="btn btn-ghost" data-action="reset">Repor dados de demonstração</button></p>`
    );
  }

  function viewLogin() {
    return shellPublic(
      "Início de sessão",
      "Entras na tua equipa de treinador.",
      `<form data-form="login">
        <div class="field">
          <label for="email">Email</label>
          <input id="email" name="email" type="email" autocomplete="username" value="miguel@email.pt" required>
        </div>
        <div class="field">
          <label for="pass">Palavra-passe</label>
          <input id="pass" name="pass" type="password" autocomplete="current-password" value="convoca" required>
          <p class="field-error" hidden></p>
        </div>
        <div class="stack">
          <button class="btn" type="submit">Entrar</button>
          <a class="btn btn-sec" href="#/recuperar">Recuperar palavra-passe</a>
        </div>
      </form>`,
      `<a class="link-quiet" href="#/registo">Registo</a>`
    );
  }

  function viewRegisto() {
    return shellPublic(
      "Criar conta de treinador",
      "Uma conta, uma equipa.",
      `<form data-form="registo">
        <div class="field"><label for="nome">Nome</label><input id="nome" name="nome" value="Miguel Santos" required></div>
        <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" value="miguel@email.pt" required></div>
        <div class="field"><label for="pass">Palavra-passe</label><input id="pass" name="pass" type="password" required></div>
        <div class="field">
          <label for="pass2">Confirmar palavra-passe</label>
          <input id="pass2" name="pass2" type="password" required>
          <p class="field-error" hidden></p>
        </div>
        <button class="btn" type="submit">Criar conta</button>
      </form>`,
      `<a class="link-quiet" href="#/login">Já tenho conta</a>`
    );
  }

  function viewRecuperar() {
    return shellPublic(
      "Recuperar palavra-passe",
      "Enviamos um link para o email da conta.",
      `<form data-form="recuperar">
        <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" value="miguel@email.pt" required></div>
        <button class="btn" type="submit">Enviar link</button>
      </form>`,
      `<a class="link-quiet" href="#/login">Voltar</a>`
    );
  }

  function viewCriarEquipa() {
    if (!db.session || db.session.role !== "coach") {
      go("/login");
      return "";
    }
    return shellPublic(
      "Nome da tua equipa",
      "Fica exclusiva desta conta. Os jogadores entram com um código que geramos a seguir.",
      `<form data-form="criar-equipa">
        <div class="field"><label for="equipa">Nome da equipa</label><input id="equipa" name="equipa" value="FC Amadora" required></div>
        <button class="btn" type="submit">Criar equipa</button>
      </form>`
    );
  }

  function viewEntrarEquipa(error) {
    return shellPublic(
      "Entrar na equipa",
      "Pede o código ao treinador.",
      `${error ? `<div class="alert" role="alert">${esc(error)}</div>` : ""}
      <form data-form="entrar-equipa">
        <div class="field"><label for="codigo">Código da equipa</label><input id="codigo" name="codigo" value="EQ-K7P2M9" autocomplete="off" required></div>
        <div class="field"><label for="nome">O teu nome</label><input id="nome" name="nome" value="Inês Costa" required></div>
        <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" value="ines@email.pt" required></div>
        <button class="btn" type="submit">Entrar na equipa</button>
      </form>`
    );
  }

  function viewJogadorSucesso() {
    const name = db.team ? db.team.name : "equipa";
    const open = nextOpenGame();
    const ines = db.players.find((p) => /inês/i.test(p.name)) || db.players[0];
    const link = open && ines ? `#/c/${tokenFor(open.id, ines.id)}` : "#/";
    return shellPublic(
      `Já estás na ${esc(name)}`,
      "Quando houver jogo, recebes um link só teu. Abre-o e diz se vais.",
      `<div class="stack">
        ${open ? `<a class="btn" href="${link}">Ver o link do próximo jogo</a>` : ""}
        <a class="btn btn-sec" href="#/">Voltar ao início</a>
      </div>`
    );
  }

  function viewPainel() {
    if (!requireCoach()) return "";
    const me = coach();
    const open = nextOpenGame();
    const ativos = db.players.filter((p) => p.active).length;
    let card;
    if (!open) {
      card = `<div class="empty">
        <h2>Ainda não há jogos</h2>
        <p class="lead">Cria a primeira convocatória e deixa de contar respostas no WhatsApp.</p>
        <a class="btn" href="#/jogos/novo">Nova convocatória</a>
      </div>`;
    } else {
      const c = counts(open);
      const w = fmtWhen(open.datetime);
      card = `<article class="card">
        <p class="kicker">Próximo jogo</p>
        <h2>${esc(w.label)} · ${esc(open.opponent)}</h2>
        <p class="muted">${c.yes + c.no} de ${c.total} confirmaram</p>
        <div class="kpis">
          <div class="kpi yes"><strong>${c.yes}</strong> Vou</div>
          <div class="kpi no"><strong>${c.no}</strong> Não vou</div>
          <div class="kpi wait"><strong>${c.wait}</strong> Pendente</div>
        </div>
        <a class="btn" href="#/jogo/${open.id}">Ver respostas</a>
      </article>`;
    }
    return `<div class="screen">
      <header class="hero compact">
        ${brand(`<a class="link-quiet" href="#/">Sair</a>`)}
        <h1>Olá, ${esc(me.name.split(" ")[0])}</h1>
        <p>${esc(db.team.name)} · ${db.players.length} jogadores · ${ativos} ativos</p>
      </header>
      <div class="body with-nav">
        ${card}
        <div class="stack" style="margin-top:14px">
          <a class="btn" href="#/jogos/novo">Nova convocatória</a>
        </div>
      </div>
      ${nav("painel")}
    </div>`;
  }

  function viewEquipa() {
    if (!requireCoach()) return "";
    return `<div class="screen">
      <header class="hero compact">
        ${brand(`<a class="link-quiet" href="#/">Sair</a>`)}
        <h1>${esc(db.team.name)}</h1>
        <p>Equipa exclusiva desta conta · ${db.players.length} jogadores</p>
      </header>
      <div class="body with-nav">
        <div class="card">
          <p class="kicker">Código para os jogadores</p>
          <div class="code-box">${esc(db.team.code)}</div>
          <button class="btn" data-action="copy-code" type="button">Copiar código</button>
        </div>
        <div class="stack" style="margin-top:12px">
          <a class="btn btn-sec" href="#/jogadores">Ver jogadores</a>
        </div>
      </div>
      ${nav("equipa")}
    </div>`;
  }

  function viewJogadores() {
    if (!requireCoach()) return "";
    const ativos = db.players.filter((p) => p.active).length;
    const list = db.players.length
      ? `<ul class="list players-grid">${db.players
          .map(
            (p) => `<li><a href="#/jogador/${p.id}"><span>${esc(p.name)}<br><small>${esc(p.phone || p.email)}</small></span>
            <span class="badge ${p.active ? "badge-solid" : ""}">${p.active ? "Ativo" : "Inativo"}</span></a></li>`
          )
          .join("")}</ul>`
      : `<div class="empty"><h2>Ainda não há jogadores</h2><p class="lead">Adiciona à mão ou partilha o código da equipa.</p><a class="btn" href="#/jogador/novo">Adicionar jogador</a></div>`;
    return `<div class="screen">
      <header class="hero compact">
        ${brand(`<a class="link-quiet" href="#/jogador/novo">Adicionar</a>`)}
        <h1>Jogadores</h1>
        <p>${db.players.length} na equipa · ${ativos} ativos</p>
      </header>
      <div class="body with-nav">${list}</div>
      ${nav("jogadores")}
    </div>`;
  }

  function viewJogadorForm(id) {
    if (!requireCoach()) return "";
    const p = id ? playerById(id) : { name: "", email: "", phone: "", active: true };
    if (id && !p) {
      go("/jogadores");
      return "";
    }
    return `<div class="screen">
      <header class="hero compact">
        ${brand(`<a class="link-quiet" href="#/jogadores">Voltar</a>`)}
        <h1>${id ? "Editar jogador" : "Adicionar jogador"}</h1>
        <p>${id ? "Atualiza contacto ou estado." : "Insere quem ainda não entrou com o código."}</p>
      </header>
      <div class="body with-nav">
        <form data-form="jogador" data-id="${id || ""}">
          <div class="field"><label for="nome">Nome</label><input id="nome" name="nome" value="${esc(p.name)}" required></div>
          <div class="field"><label for="email">Email (para o link da convocatória)</label><input id="email" name="email" type="email" value="${esc(p.email)}"></div>
          <div class="field"><label for="tel">Telemóvel</label><input id="tel" name="tel" type="tel" value="${esc(p.phone)}"></div>
          ${id ? `<label class="check"><input type="checkbox" name="ativo" ${p.active ? "checked" : ""}> Jogador ativo (entra nas convocatórias)</label>` : ""}
          <button class="btn" type="submit">${id ? "Guardar alterações" : "Guardar jogador"}</button>
        </form>
      </div>
      ${nav("jogadores")}
    </div>`;
  }

  function viewJogos() {
    if (!requireCoach()) return "";
    const list = db.games.length
      ? `<ul class="list">${db.games
          .slice()
          .sort((a, b) => b.datetime.localeCompare(a.datetime))
          .map((g) => {
            const c = counts(g);
            const w = fmtWhen(g.datetime);
            const badge = g.closed
              ? `<span class="badge">Fechado</span>`
              : `<span class="badge badge-solid">${c.yes} vou · ${c.wait} falta</span>`;
            return `<li><a href="#/jogo/${g.id}"><span>${esc(w.short)} · ${esc(g.opponent)}<br><small>${esc(g.venue)}</small></span>${badge}</a></li>`;
          })
          .join("")}</ul>`
      : `<div class="empty"><h2>Ainda não há jogos</h2><p class="lead">A primeira convocatória aparece aqui.</p><a class="btn" href="#/jogos/novo">Nova convocatória</a></div>`;
    return `<div class="screen">
      <header class="hero compact">
        ${brand(`<a class="link-quiet" href="#/jogos/novo">Nova</a>`)}
        <h1>Jogos</h1>
        <p>Data, adversário e resumo das respostas.</p>
      </header>
      <div class="body with-nav">${list}</div>
      ${nav("jogos")}
    </div>`;
  }

  function viewNova(error) {
    if (!requireCoach()) return "";
    const ativos = db.players.filter((p) => p.active);
    const checks = db.players
      .map(
        (p) =>
          `<label class="check"><input type="checkbox" name="pid" value="${p.id}" ${p.active ? "checked" : ""}> ${esc(p.name)}${p.active ? "" : " (inativo)"}</label>`
      )
      .join("");
    return `<div class="screen">
      <header class="hero compact">
        ${brand(`<a class="link-quiet" href="#/jogos">Voltar</a>`)}
        <h1>Nova convocatória</h1>
        <p>Jogo, data e atletas num só ecrã.</p>
      </header>
      <div class="body with-nav">
        ${error ? `<div class="alert" role="alert">${esc(error)}</div>` : ""}
        <form data-form="nova">
          <div class="field"><label for="adv">Adversário</label><input id="adv" name="adv" value="Académico" required></div>
          <div class="field"><label for="local">Local</label><input id="local" name="local" value="Campo da Moita" required></div>
          <div class="field"><label for="data">Data e hora</label><input id="data" name="data" type="datetime-local" value="2026-11-07T10:00" required></div>
          <div class="field"><label for="notas">Notas (opcional)</label><textarea id="notas" name="notas">Concentração às 9h15.</textarea></div>
          <p><strong>Jogadores</strong> · ${ativos.length} ativos pré-selecionados</p>
          ${checks || "<p class='lead'>Adiciona jogadores primeiro.</p>"}
          <div class="stack" style="margin-top:12px">
            <button class="btn" type="submit">Enviar convocatória</button>
          </div>
        </form>
      </div>
      ${nav("jogos")}
    </div>`;
  }

  function viewJogo(id) {
    if (!requireCoach()) return "";
    const g = db.games.find((x) => x.id === id);
    if (!g) {
      go("/jogos");
      return "";
    }
    const c = counts(g);
    const w = fmtWhen(g.datetime);
    const rows = g.called
      .map((pid) => {
        const p = playerById(pid);
        if (!p) return "";
        const r = g.responses[pid];
        const label = r === "yes" ? "Vou" : r === "no" ? "Não vou" : "Pendente";
        const cls = r === "yes" ? "badge-yes" : r === "no" ? "badge-no" : "badge-wait";
        const tok = tokenFor(g.id, p.id);
        return `<div class="player-row">
          <div><strong>${esc(p.name)}</strong><br><small class="muted">${esc(p.email || p.phone)}</small></div>
          <div style="text-align:right">
            <span class="badge ${cls}">${label}</span><br>
            <a class="link-mini" href="#/c/${tok}">Abrir link</a>
            <button class="link-mini" data-action="copy-link" data-token="${tok}" type="button">Copiar</button>
          </div>
        </div>`;
      })
      .join("");
    return `<div class="screen">
      <header class="hero compact">
        ${brand(`<a class="link-quiet" href="#/jogos">Jogos</a>`)}
        <h1>vs. ${esc(g.opponent)}</h1>
        <p>${esc(w.label)} · ${esc(g.venue)}</p>
      </header>
      <div class="body with-nav">
        <div class="kpis">
          <div class="kpi yes"><strong>${c.yes}</strong> Vou</div>
          <div class="kpi no"><strong>${c.no}</strong> Não vou</div>
          <div class="kpi wait"><strong>${c.wait}</strong> Pendente</div>
        </div>
        <div class="stack" style="margin-bottom:14px">
          ${g.closed ? "" : `<button class="btn" data-action="lembrar" data-id="${g.id}" type="button">Lembrar quem falta</button>`}
          ${g.closed ? `<div class="alert">Esta convocatória está fechada.</div>` : `<button class="btn btn-sec" data-action="fechar" data-id="${g.id}" type="button">Fechar convocatória</button>`}
        </div>
        <div class="card">${rows || "<p>Ninguém convocado.</p>"}</div>
      </div>
      ${nav("jogos")}
    </div>`;
  }

  function viewConfirmar(token) {
    const { gameId, playerId } = parseToken(token);
    const g = db.games.find((x) => x.id === gameId);
    const p = playerById(playerId);
    if (!g || !p || !g.called.includes(p.id)) {
      go("/link-invalido");
      return "";
    }
    if (g.closed) {
      const last = g.responses[p.id];
      const lastTxt = last === "yes" ? "Vou" : last === "no" ? "Não vou" : "Sem resposta";
      const w = fmtWhen(g.datetime);
      return `<div class="screen"><div class="confirm">
        <p class="chip">${esc(db.team.name)} · ${esc(p.name)}</p>
        <h1>Já não podes alterar</h1>
        <div class="meta-card">
          <p>${esc(w.label)} · ${esc(g.opponent)}</p>
          <p class="muted">A convocatória está fechada.</p>
          <p>A tua última resposta: <strong>${lastTxt}</strong></p>
        </div>
        <div class="actions"><a class="btn" href="#/">Ir para o início</a></div>
      </div></div>`;
    }
    const w = fmtWhen(g.datetime);
    const r = g.responses[p.id];
    const title = r === "yes" ? "Vais ao jogo" : r === "no" ? "Não vais ao jogo" : `Jogo vs. ${esc(g.opponent)}`;
    const hint =
      r == null
        ? "Este link é só teu. Não o partilhes no grupo."
        : "O treinador já vê a tua resposta. Podes mudar enquanto o jogo estiver aberto.";
    return `<div class="screen"><div class="confirm">
      <p class="chip">${esc(db.team.name)} · ${esc(p.name)}</p>
      <h1>${title}</h1>
      <div class="meta-card">
        <p>${esc(w.label)}</p>
        <p>${esc(g.venue)}</p>
        ${g.notes ? `<p class="muted">${esc(g.notes)}</p>` : ""}
      </div>
      <p class="hint">${hint}</p>
      <div class="actions">
        <button class="btn ${r === "yes" ? "is-on" : ""}" data-action="reply" data-token="${esc(token)}" data-reply="yes" type="button">Vou ao jogo</button>
        <button class="btn btn-sec ${r === "no" ? "is-on" : ""}" data-action="reply" data-token="${esc(token)}" data-reply="no" type="button">Não vou</button>
      </div>
    </div></div>`;
  }

  function viewLinkInvalido() {
    return `<div class="screen"><div class="confirm">
      <p class="chip">Convoca</p>
      <h1>Este link não funciona</h1>
      <div class="meta-card"><p>Pode estar incompleto ou já não ser válido. Pede um novo link ao treinador.</p></div>
      <div class="actions"><a class="btn" href="#/">Ir para o início</a></div>
    </div></div>`;
  }

  function render() {
    $("#clock").textContent = nowClock();
    const { parts } = parseRoute();
    const root = parts[0] || "";
    let html = "";
    if (!root) html = viewInicio();
    else if (root === "login") html = viewLogin();
    else if (root === "registo") html = viewRegisto();
    else if (root === "recuperar") html = viewRecuperar();
    else if (root === "criar-equipa") html = viewCriarEquipa();
    else if (root === "entrar-equipa") html = viewEntrarEquipa();
    else if (root === "jogador-sucesso") html = viewJogadorSucesso();
    else if (root === "painel") html = viewPainel();
    else if (root === "equipa") html = viewEquipa();
    else if (root === "jogadores") html = viewJogadores();
    else if (root === "jogador" && parts[1] === "novo") html = viewJogadorForm();
    else if (root === "jogador") html = viewJogadorForm(parts[1]);
    else if (root === "jogos" && parts[1] === "novo") html = viewNova();
    else if (root === "jogos") html = viewJogos();
    else if (root === "jogo") html = viewJogo(parts[1]);
    else if (root === "c") html = viewConfirmar(parts[1]);
    else if (root === "link-invalido") html = viewLinkInvalido();
    else html = viewInicio();
    $("#app").innerHTML = html;
    document.title = "Convoca";
  }

  function onLogin(form) {
    const email = form.email.value.trim().toLowerCase();
    const pass = form.pass.value;
    const found = db.coaches.find((c) => c.email.toLowerCase() === email && c.pass === pass);
    const err = form.querySelector(".field-error");
    if (!found) {
      err.hidden = false;
      err.textContent = "Email ou palavra-passe incorretos.";
      form.pass.setAttribute("aria-invalid", "true");
      return;
    }
    db.session = { role: "coach", coachId: found.id };
    save();
    go(db.team ? "/painel" : "/criar-equipa");
  }

  function onRegisto(form) {
    const err = form.querySelector(".field-error");
    if (form.pass.value !== form.pass2.value) {
      err.hidden = false;
      err.textContent = "As palavras-passe não coincidem.";
      form.pass2.setAttribute("aria-invalid", "true");
      return;
    }
    const email = form.email.value.trim().toLowerCase();
    db.coaches = db.coaches.filter((c) => c.email.toLowerCase() !== email);
    const id = uid("c");
    db.coaches.push({
      id,
      name: form.nome.value.trim(),
      email,
      pass: form.pass.value
    });
    db.team = null;
    db.players = [];
    db.games = [];
    db.session = { role: "coach", coachId: id };
    save();
    go("/criar-equipa");
  }

  function onCriarEquipa(form) {
    const code = "EQ-" + Math.random().toString(36).slice(2, 8).toUpperCase();
    db.team = { name: form.equipa.value.trim(), code, coachId: db.session.coachId };
    save();
    toast("Equipa criada. Partilha o código.");
    go("/equipa");
  }

  function onEntrarEquipa(form) {
    const code = form.codigo.value.trim().toUpperCase();
    if (!db.team || code !== db.team.code) {
      $("#app").innerHTML = viewEntrarEquipa("Este código não existe. Confirma com o treinador.");
      return;
    }
    const email = form.email.value.trim().toLowerCase();
    let p = db.players.find((x) => x.email.toLowerCase() === email);
    if (!p) {
      p = {
        id: uid("p"),
        name: form.nome.value.trim(),
        email,
        phone: "",
        active: true
      };
      db.players.push(p);
    } else {
      p.name = form.nome.value.trim();
      p.active = true;
    }
    save();
    go("/jogador-sucesso");
  }

  function onJogador(form) {
    const id = form.getAttribute("data-id");
    const data = {
      name: form.nome.value.trim(),
      email: form.email.value.trim(),
      phone: form.tel.value.trim(),
      active: form.ativo ? form.ativo.checked : true
    };
    if (id) {
      const p = playerById(id);
      Object.assign(p, data);
    } else {
      db.players.push({ id: uid("p"), ...data });
    }
    save();
    toast("Jogador guardado");
    go("/jogadores");
  }

  function onNova(form) {
    const called = [...form.querySelectorAll('input[name="pid"]:checked')].map((i) => i.value);
    if (!called.length) {
      $("#app").innerHTML = viewNova("Escolhe pelo menos um jogador.");
      return;
    }
    const responses = {};
    called.forEach((id) => (responses[id] = null));
    const game = {
      id: uid("g"),
      opponent: form.adv.value.trim(),
      venue: form.local.value.trim(),
      datetime: form.data.value,
      notes: form.notas.value.trim(),
      closed: false,
      called,
      responses
    };
    db.games.unshift(game);
    save();
    toast("Convocatória enviada");
    go("/jogo/" + game.id);
  }

  document.addEventListener("submit", (e) => {
    const form = e.target.closest("form[data-form]");
    if (!form) return;
    e.preventDefault();
    const kind = form.getAttribute("data-form");
    if (kind === "login") onLogin(form);
    if (kind === "registo") onRegisto(form);
    if (kind === "recuperar") {
      toast("Se o email existir, enviámos o link.");
      go("/login");
    }
    if (kind === "criar-equipa") onCriarEquipa(form);
    if (kind === "entrar-equipa") onEntrarEquipa(form);
    if (kind === "jogador") onJogador(form);
    if (kind === "nova") onNova(form);
  });

  document.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-action]");
    if (!btn) return;
    const action = btn.getAttribute("data-action");
    if (action === "reset") {
      db = seed();
      save();
      toast("Dados de demonstração repostos");
      go("/");
      render();
    }
    if (action === "copy-code") copy(db.team.code, "Código copiado");
    if (action === "copy-link") {
      const url = location.origin + location.pathname + "#/c/" + btn.getAttribute("data-token");
      copy(url, "Link único copiado");
    }
    if (action === "lembrar") {
      const g = db.games.find((x) => x.id === btn.getAttribute("data-id"));
      const n = counts(g).wait;
      toast(n ? `Lembrete enviado a ${n} jogador${n === 1 ? "" : "es"}` : "Toda a gente já respondeu");
    }
    if (action === "fechar") {
      const g = db.games.find((x) => x.id === btn.getAttribute("data-id"));
      g.closed = true;
      save();
      toast("Convocatória fechada");
      render();
    }
    if (action === "reply") {
      const token = btn.getAttribute("data-token");
      const reply = btn.getAttribute("data-reply");
      const { gameId, playerId } = parseToken(token);
      const g = db.games.find((x) => x.id === gameId);
      if (g && !g.closed) {
        g.responses[playerId] = reply;
        save();
        toast(reply === "yes" ? "Presença confirmada" : "Ausência confirmada");
        render();
      }
    }
  });

  window.addEventListener("hashchange", render);
  setInterval(() => {
    const c = $("#clock");
    if (c) c.textContent = nowClock();
  }, 30000);
  render();
})();
