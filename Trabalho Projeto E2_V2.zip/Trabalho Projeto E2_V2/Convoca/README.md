# Convoca

App móvel de convocatórias para uma equipa de futebol amador. O treinador cria o jogo, envia a convocatória e vê quem vai. O jogador abre um link único e responde **Vou** ou **Não vou**.

Abre `index.html` no telemóvel (ou no browser do computador: a interface está desenhada a 430 px).

## Conta de demonstração

- Treinador: `miguel@email.pt` / `convoca`
- Código da equipa: `EQ-K7P2M9`
- Link do jogo: no ecrã inicial, **Abri o link do jogo** (Inês, vs. Académico)

Os dados ficam gravados neste browser. No início podes **Repor dados de demonstração**.
